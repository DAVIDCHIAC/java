/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */

import robot.Robot;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author B12
 */
public class RobotTest {
    
    public RobotTest() {
    }
    
    @BeforeAll
    public static void setUpClass() {
    }
    
    @AfterAll
    public static void tearDownClass() {
    }
    
    @BeforeEach
    public void setUp() {
    }
    
    @AfterEach
    public void tearDown() {
    }

    /**
     * Test of florecer method, of class Robot.
     */
    @Test
    public void testFlorecer() {
        System.out.println("florecer");
        Robot instance = null;
        instance.florecer();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of marchitar method, of class Robot.
     */
    @Test
    public void testMarchitar() {
        System.out.println("marchitar");
        Robot instance = null;
        instance.marchitar();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of mostrarDetalles method, of class Robot.
     */
    @Test
    public void testMostrarDetalles() {
        System.out.println("mostrarDetalles");
        Robot instance = null;
        instance.mostrarDetalles();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of podar method, of class Robot.
     */
    @Test
    public void testPodar() {
        System.out.println("podar");
        Robot instance = null;
        instance.podar();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of necesitaAgua method, of class Robot.
     */
    @Test
    public void testNecesitaAgua() {
        System.out.println("necesitaAgua");
        Robot instance = null;
        boolean expResult = false;
        boolean result = instance.necesitaAgua();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getColor method, of class Robot.
     */
    @Test
    public void testGetColor() {
        System.out.println("getColor");
        Robot instance = null;
        String expResult = "";
        String result = instance.getColor();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of setColor method, of class Robot.
     */
    @Test
    public void testSetColor() {
        System.out.println("setColor");
        String color = "";
        Robot instance = null;
        instance.setColor(color);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getTipo method, of class Robot.
     */
    @Test
    public void testGetTipo() {
        System.out.println("getTipo");
        Robot instance = null;
        String expResult = "";
        String result = instance.getTipo();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of setTipo method, of class Robot.
     */
    @Test
    public void testSetTipo() {
        System.out.println("setTipo");
        String tipo = "";
        Robot instance = null;
        instance.setTipo(tipo);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getCantidadPétalos method, of class Robot.
     */
    @Test
    public void testGetCantidadPétalos() {
        System.out.println("getCantidadP\u00e9talos");
        Robot instance = null;
        int expResult = 0;
        int result = instance.getCantidadPétalos();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of setCantidadPétalos method, of class Robot.
     */
    @Test
    public void testSetCantidadPétalos() {
        System.out.println("setCantidadP\u00e9talos");
        int cantidadPétalos = 0;
        Robot instance = null;
        instance.setCantidadPétalos(cantidadPétalos);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of isEspinas method, of class Robot.
     */
    @Test
    public void testIsEspinas() {
        System.out.println("isEspinas");
        Robot instance = null;
        boolean expResult = false;
        boolean result = instance.isEspinas();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of setEspinas method, of class Robot.
     */
    @Test
    public void testSetEspinas() {
        System.out.println("setEspinas");
        boolean espinas = false;
        Robot instance = null;
        instance.setEspinas(espinas);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
    
}

package robot;

public class Robot {
    
    // Atributos
    private String modelo;
    private String fabricante;
    private int bateria;
    private boolean encendido;
    private double peso;

    // Constructor
    public Robot(String modelo, String fabricante, int bateria, boolean encendido, double peso) {
        this.modelo = modelo;
        this.fabricante = fabricante;
        this.bateria = bateria;
        this.encendido = encendido;
        this.peso = peso;
    }

    // Métodos
    public void encender() {
        if (!encendido) {
            encendido = true;
            System.out.println("El robot " + modelo + " está encendido.");
        } else {
            System.out.println("El robot ya está encendido.");
        }
    }

    public void apagar() {
        if (encendido) {
            encendido = false;
            System.out.println("El robot " + modelo + " está apagado.");
        } else {
            System.out.println("El robot ya está apagado.");
        }
    }

    public void cargarBateria(int cantidad) {
        bateria += cantidad;
        if (bateria > 100) {
            bateria = 100;
        }
        System.out.println("Batería cargada. Nivel actual: " + bateria + "%");
    }

    public boolean necesitaCarga() {
        return bateria < 20;
    }

    public void realizarTarea(String tarea) {
        if (encendido) {
            System.out.println("El robot " + modelo + " está realizando la tarea: " + tarea);
        } else {
            System.out.println("El robot está apagado y no puede realizar tareas.");
        }
    }

    // Getters y Setters
    public String getModelo() {
        return modelo;
    }

    public void setModelo(String modelo) {
        this.modelo = modelo;
    }

    public String getFabricante() {
        return fabricante;
    }

    public void setFabricante(String fabricante) {
        this.fabricante = fabricante;
    }

    public int getBateria() {
        return bateria;
    }

    public void setBateria(int bateria) {
        this.bateria = bateria;
    }

    public boolean isEncendido() {
        return encendido;
    }

    public void setEncendido(boolean encendido) {
        this.encendido = encendido;
    }

    public double getPeso() {
        return peso;
    }

    public void setPeso(double peso) {
        this.peso = peso;
    }

    public static void main(String[] args) {
        // Crear objetos de la clase Robot
        Robot robot1 = new Robot("RX-78", "RobotCorp", 85, false, 12.5);
        Robot robot2 = new Robot("R2-D2", "Galactic Robotics", 50, true, 15.0);
        Robot robot3 = new Robot("C-3PO", "Galactic Robotics", 70, true, 10.0);

        // Imprimir un atributo de cada objeto
        System.out.println("Modelo de robot 1: " + robot1.getModelo());
        System.out.println("Modelo de robot 2: " + robot2.getModelo());
        System.out.println("Modelo de robot 3: " + robot3.getModelo());
    }
}


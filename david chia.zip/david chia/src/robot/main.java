/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package robot;

/**
 *
 * @author B12
 */
public class main {
    public static void main(String args[]){
        Robot r1= new Robot("2024","apple",800,true,1500);
        r1.encender();
    }
}

public class Rosa {
    
    private String color;
    private String tipo;
    private int cantidadPétalos;
    private boolean espinas;
    private final double altura;


    public Rosa(String color, String tipo, int cantidadPétalos, boolean espinas, double altura) {
        this.color = color;
        this.tipo = tipo;
        this.cantidadPétalos = cantidadPétalos;
        this.espinas = espinas;
        this.altura = altura;
    }

    
    public void florecer() {
        System.out.println("La rosa " + color + " está floreciendo.");
    }

    public void marchitar() {
        System.out.println("La rosa " + color + " se está marchitando.");
    }

    public void mostrarDetalles() {
        System.out.println("Detalles de la rosa:");
        System.out.println("Color: " + color);
        System.out.println("Tipo: " + tipo);
        System.out.println("Cantidad de pétalos: " + cantidadPétalos);
        System.out.println("¿Tiene espinas? " + (espinas ? "Sí" : "No"));
        System.out.println("Altura: " + altura + " cm");
    }

    public void podar() {
        System.out.println("Se ha podado la rosa " + color + ".");
    }

    public boolean necesitaAgua() {
        // Suponiendo que necesita agua si la altura es menor a 30 cm
        return altura < 30;
    }

    
    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public int getCantidadPétalos() {
        return cantidadPétalos;
    }

    public void setCantidadPétalos(int cantidadPétalos) {
        this.cantidadPétalos = cantidadPétalos;
    }

    public boolean isEspinas() {
        return espinas;
    }

    public void setEspinas(boolean espinas) {
        this.espinas=espinas;
    }
}
                